using System.Collections.Generic;
using System.Linq;
using System;

namespace PrimesCalculation
{
    public class ReactiveSchedulingStrategy {
        private Dictionary<int, QueryTracker> queryId2Tracker;
        private Dictionary<IWorkerGrain, QueryTracker> worker2Tracker;

        public ReactiveSchedulingStrategy() {
            queryId2Tracker = new Dictionary<int, QueryTracker>();
            worker2Tracker = new Dictionary<IWorkerGrain, QueryTracker>();
        }

        public void schedule(int taskId, int start, int end) {
            QueryTracker tracker = new QueryTracker(taskId, start, end);
            queryId2Tracker.Add(taskId, tracker);
            assignSubqueries();
        }

        public bool hasTasksInProgress() {
            return queryId2Tracker.Count > 0;
        }

        public void finished(int taskId, IWorkerGrain worker) {            
            QueryTracker tracker = queryId2Tracker[taskId];
            tracker.workCompleted(worker);
            worker2Tracker[worker] = null;

            if (tracker.checkComplete()) {
                queryId2Tracker.Remove(taskId);
            } else {
                assignSubqueries();
            }
        }

        public void addWorker(IWorkerGrain worker) {
            worker2Tracker.Add(worker, null);
            assignSubqueries();
        }

        public void removeWorker(IWorkerGrain worker) {
            QueryTracker tracker = worker2Tracker[worker];
            worker2Tracker.Remove(worker);
            if (tracker != null) {
                tracker.workFailed(worker);
                assignSubqueries();
            }
        }

        private void assignSubqueries() {
            List<IWorkerGrain> idleWorkers = new List<IWorkerGrain>();
            foreach (var worker in worker2Tracker.Keys)
            {
                if (worker2Tracker[worker] == null) {
                    idleWorkers.Add(worker);
                }
            }

            if (idleWorkers.Count == 0 || queryId2Tracker.Count == 0) return;

            List<QueryTracker> queryTrackers = queryId2Tracker.Values.ToList();
            int queryTrackerId = 0;
            QueryTracker tracker = queryTrackers[queryTrackerId];

            foreach (var idleWorker in idleWorkers)
            {
                while (!tracker.assignWork(idleWorker))
                {
                    queryTrackerId++;
                    if (queryTrackers.Count <= queryTrackerId) break;
                    
                    tracker = queryTrackers[queryTrackerId];
                    if (tracker == null) return;
                }
                worker2Tracker[idleWorker] = tracker;
            }
        }

        public int countWorkers() {
            return worker2Tracker.Count;
        }
    }

    public class QueryTracker {
        private const int MAX_SUBQUERY_RANGE_SIZE = 100_000;
        private int remainingRangeStart;
        private int remainingRangeEnd;
        private int id;
        private Dictionary<IWorkerGrain, Work> runningSubqueries;
        private List<Work> failedSubqueries;

        public QueryTracker(int tracker_id, int start, int end) {
            remainingRangeStart = start;
            remainingRangeEnd = end;
            id = tracker_id;
            runningSubqueries = new Dictionary<IWorkerGrain, Work>();
            failedSubqueries = new List<Work>();
        }

        public bool assignWork(IWorkerGrain worker) {
            Work work;

            if (failedSubqueries.Count > 0) {
                work = failedSubqueries[0];
                failedSubqueries.RemoveAt(0);
            } else {
                int subqueryRangeSize = Math.Min(remainingRangeEnd - (remainingRangeStart - 1), MAX_SUBQUERY_RANGE_SIZE);
                if (subqueryRangeSize > 0) {
                    work = new Work(id, remainingRangeStart, remainingRangeStart + subqueryRangeSize - 1);
                    remainingRangeStart += subqueryRangeSize;
                } else {
                    return false; // substitute for condition
                }
            }

            // if (work == null) return false;

            worker.FindPrime(work);

            runningSubqueries.Add(worker, work);

            return true;
        }

        public void workFailed(IWorkerGrain worker) {
            Work failedTask = runningSubqueries[worker];
            runningSubqueries.Remove(worker);
            failedSubqueries.Add(failedTask);
        }

        public void workCompleted(IWorkerGrain worker) {
            runningSubqueries.Remove(worker);
        }

        public bool checkComplete() {
            return runningSubqueries.Count == 0 && failedSubqueries.Count == 0 && remainingRangeStart > remainingRangeEnd;
        }

    }
}