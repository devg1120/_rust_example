using System;


namespace PrimesCalculation {
    public class Parameters {
        public int numNodes;
        public int numLocalWorkers;
        public int start;
        public int end;
        public int port;
        public string host;
        public int hostPort;
        public int id;


        public Parameters(int numNodes, int numLocalWorkers, int start, int end, int port, int hostPort, int id, string host) {
            this.numNodes = numNodes;
            this.numLocalWorkers = numLocalWorkers;
            this.start = start;
            this.end = end;
            this.port = port;
            this.hostPort = hostPort;
            this.host = host;
            this.id = id;
        }

        public static Parameters FromArgs(string[] arguments) {
            int numNodes = 1;
            int numLocalWorkers = 1;
            int start = 1;
            int end = 1000;
            int port = 11111;
            int hostPort = 0;
            string host = "0.0.0.0";
            int id = 0;

            foreach (string arg in arguments) {
                if (arg.StartsWith("--numNodes=")) {
                    numNodes = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--numLocalWorkers=")) {
                    numLocalWorkers = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--start=")) {
                    start = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--end=")) {
                    end = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--port=")) {
                    port = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--hostPort=")) {
                    hostPort = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--id=")) {
                    id = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--host=")) {
                    host = arg.Split("=")[1];
                }
            }

            return new Parameters(numNodes, numLocalWorkers, start, end, port, hostPort, id, host);
        }
    }
}