using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Orleans;
using Orleans.Placement;


namespace PrimesCalculation {
    [PreferLocalPlacement]
    public class Worker: Grain, IWorkerGrain {
        public int MAX_PRIMES_PER_MESSAGE = 1000;
        private IProfilerGrain profiler;

        public void log(string text) {
            var id = this.GetPrimaryKey().ToString();
            Console.WriteLine("Worker-{0}:\t{1}", id, text);
        }

        public Task Register(IProfilerGrain at) {
            log("register");
            profiler = at;
            at.Subscribe(this);
            return Task.CompletedTask;
        }

        public Task FindPrime(Work work) {
            //log("starting search for primes " + work.start.ToString() + " - " + work.end.ToString());

            List<int> primeBuffer = new List<int>();

            for (int i = work.start; i <= work.end; i++)
            {
                if (isPrime(i))
                {
                    if (primeBuffer.Count >= MAX_PRIMES_PER_MESSAGE) {
                        profiler.Primes(this, primeBuffer, work.id, false);
                        primeBuffer.Clear();
                    }
                    primeBuffer.Add(i);
                    //log("found prime " + i.ToString());
                }
            }
            profiler.Primes(this, primeBuffer, work.id, true);

            return Task.CompletedTask;
        }

        public static bool isPrime(int n) {
            if (n == 1) {
                return false;
            }

            // Check for the most basic primes
            if (n == 2 || n == 3) {
                return true;
            }

            // Check if n is an even number
            if (n % 2 == 0) {
                return false;
            }

            // Check the odds
            for (long i = 3; i * i <= n; i += 2)
                if (n % i == 0)
                    return false;

            return true;
        }
    }

    public class Work
    {
        public int id;
        public int start;
        public int end;

        public Work(int id, int start, int end) {
            this.id = id;
            this.start = start;
            this.end = end;
        }
    }
    
}
