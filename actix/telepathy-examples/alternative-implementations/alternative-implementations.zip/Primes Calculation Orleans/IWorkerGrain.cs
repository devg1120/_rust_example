using System.Threading.Tasks;
using Orleans;


namespace PrimesCalculation {
    public interface IWorkerGrain : IGrainWithIntegerKey {
        Task Register(IProfilerGrain at);
        Task FindPrime(Work work);
    }
}