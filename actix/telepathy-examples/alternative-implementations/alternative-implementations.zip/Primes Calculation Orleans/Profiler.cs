using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Orleans;
using Orleans.Placement;


namespace PrimesCalculation {
    [PreferLocalPlacement]
    public class Profiler: Grain, IProfilerGrain {
        private ReactiveSchedulingStrategy schedulingStrategy;
        private List<IWorkerGrain> subscribedWorkers;
        private List<Tuple<int, int>> rangeMessages;
        private List<int> primes;
        private int num_nodes;
        private int num_local_workers;
        private int nextQueryId;
        private bool finished = false;

        public static void log(string text) {
            Console.WriteLine("Profiler:\t{0}", text);
        }

        public Task Init(int numNodes, int numLocalWorkers) {
            log("Init");

            schedulingStrategy = new ReactiveSchedulingStrategy();
            subscribedWorkers = new List<IWorkerGrain>();
            rangeMessages = new List<Tuple<int, int>>();
            primes = new List<int>();
            num_nodes = numNodes;
            num_local_workers = numLocalWorkers;
            nextQueryId = 0;
            
            return Task.CompletedTask;
        }

        public Task Range(int start, int end) {
            log("Waiting for " + (num_nodes * num_local_workers).ToString() + " workers to register...");

            if (subscribedWorkers.Count >= num_nodes * num_local_workers) {
                handleRangeMessage(start, end);
            } else {
                rangeMessages.Add(new Tuple<int, int>(start, end));
            }
            return Task.CompletedTask;
        }

        public Task Subscribe(IWorkerGrain worker) {
            schedulingStrategy.addWorker(worker);
            subscribedWorkers.Add(worker);

            log(worker.GetPrimaryKey().ToString() + " registered");

            if (subscribedWorkers.Count >= num_nodes * num_local_workers) {
                handleRangeMessages();
            }

            return Task.CompletedTask;
        }

        public Task Primes(IWorkerGrain from, List<int> primes, int id, bool isComplete) {
            //log("Received " + primes.Count.ToString() + " primes");

            this.primes.AddRange(primes);

            if (!isComplete) {
                return Task.CompletedTask;
            }

            schedulingStrategy.finished(id, from);

            if (hasFinished()) {
                log("Has finished! Found: " + this.primes.Count + " primes");
                this.finished = true;
            }

            return Task.CompletedTask;
        }

        public Task<bool> IsFinished() {
            return Task.FromResult(this.finished);
        }

        private void handleRangeMessages() {
            log("All workers registered!");
            foreach (var range in rangeMessages) {
                handleRangeMessage(range.Item1, range.Item2);
            }
            rangeMessages.Clear();
        }

        private void handleRangeMessage(int start, int end) {
            schedulingStrategy.schedule(nextQueryId++, start, end);
        }

        private bool hasFinished() {
            return (!schedulingStrategy.hasTasksInProgress()) || schedulingStrategy.countWorkers() < 1;
        }
    }
    
}