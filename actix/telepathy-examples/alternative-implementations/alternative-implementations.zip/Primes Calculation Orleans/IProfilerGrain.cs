using System.Threading.Tasks;
using System.Collections.Generic;
using Orleans;


namespace PrimesCalculation {
    public interface IProfilerGrain : IGrainWithIntegerKey {
        Task Init(int numNodes, int numLocalWorkers);
        Task Range(int start, int end);
        Task Subscribe(IWorkerGrain worker);
        Task Primes(IWorkerGrain from, List<int> primes, int id, bool isComplete);
        Task<bool> IsFinished();
    }
}