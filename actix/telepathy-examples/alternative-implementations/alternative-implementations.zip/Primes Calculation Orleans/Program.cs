using System;
using System.Net;
using PrimesCalculation;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection; 
using Orleans.Configuration;
using Orleans;
using Orleans.Hosting;


string[] arguments = Environment.GetCommandLineArgs();
Parameters parameters = Parameters.FromArgs(arguments);

await RunMain(parameters);


async Task RunMain(Parameters parameters) {
    // Configure the host
    // var host = new HostBuilder()
    //     .UseOrleans(builder => builder.UseLocalhostClustering())
    //     .Build();

    IPEndPoint primarySiloEndpoint;
    if (parameters.hostPort > 0) {
        primarySiloEndpoint = new IPEndPoint(IPAddress.Parse(parameters.host), parameters.hostPort);
        Console.WriteLine("Connecting to " + parameters.host);
    } else {
        primarySiloEndpoint = null;
    }

    var silo = new SiloHostBuilder().Configure<ClusterOptions>(options => {
        options.ClusterId = "primes-cluster";
        options.ServiceId = "PrimesApp";
    })
    .UseDevelopmentClustering(primarySiloEndpoint: primarySiloEndpoint)
    .ConfigureApplicationParts(parts => parts.AddApplicationPart(typeof(IProfilerGrain).Assembly).WithReferences())
    .ConfigureEndpoints(siloPort: parameters.port, gatewayPort: 30000)
    .Build();

    // Start the host
    await silo.StartAsync();

    // Get the grain factory
    var grainFactory = silo.Services.GetRequiredService<IGrainFactory>();

    // Get a reference to the ProfilerGrain grain with the key 0
    var profiler = grainFactory.GetGrain<IProfilerGrain>(0);
    
    if (primarySiloEndpoint == null) {
        await profiler.Init(parameters.numNodes, parameters.numLocalWorkers);
        await profiler.Range(parameters.start, parameters.end);
    }

    // Register the local workers
    int offset = parameters.numLocalWorkers * parameters.id;
    for (int i = offset; i < offset + parameters.numLocalWorkers; i++)
    {
        await grainFactory.GetGrain<IWorkerGrain>(i).Register(profiler);
    }

    while (!(await profiler.IsFinished())) {
        await Task.Delay(500);
    }
    Console.WriteLine("Shutting down...");

    await silo.StopAsync();

    return;
}
