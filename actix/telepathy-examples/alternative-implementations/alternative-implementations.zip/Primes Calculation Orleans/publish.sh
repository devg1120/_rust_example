dotnet publish -r linux-x64 --self-contained true
