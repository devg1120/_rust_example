package de.anonymous.powerpingpong;

    import java.util.concurrent.TimeoutException;

import com.typesafe.config.Config;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.cluster.Cluster;
import de.anonymous.powerpingpong.actors.ClusterListener;
import de.anonymous.powerpingpong.actors.Multiplier;
import scala.concurrent.Await;
import scala.concurrent.duration.Duration;

public class PowerPingPongMain extends PowerPingPongSystem {

    public static final String MAIN_ROLE = "main";

    public static void start(String actorSystemName, String host, int port, int steps) {

        final Config config = createConfiguration(actorSystemName, MAIN_ROLE, host, port, host, port);

        final ActorSystem system = createSystem(actorSystemName, config);

        Cluster.get(system).registerOnMemberUp(new Runnable() {
            @Override
            public void run() {
                ActorRef multiplier = system.actorOf(Multiplier.props(steps), Multiplier.DEFAULT_NAME);
                system.actorOf(ClusterListener.props(multiplier), ClusterListener.DEFAULT_NAME);
            }
        });

        try {
            Await.ready(system.whenTerminated(), Duration.Inf());
        } catch (TimeoutException | InterruptedException e) {
            e.printStackTrace();
            System.exit(-1);
        }
        System.out.println("ActorSystem terminated!");
    }
}
