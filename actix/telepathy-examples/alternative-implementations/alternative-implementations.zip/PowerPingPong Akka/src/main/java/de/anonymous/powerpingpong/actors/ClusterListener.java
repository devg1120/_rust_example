package de.anonymous.powerpingpong.actors;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.ActorSelection;
import akka.actor.Props;
import akka.cluster.Cluster;
import akka.cluster.ClusterEvent.CurrentClusterState;
import akka.cluster.ClusterEvent.MemberEvent;
import akka.cluster.ClusterEvent.MemberUp;
import akka.cluster.ClusterEvent.MemberRemoved;
import akka.cluster.ClusterEvent.UnreachableMember;
import akka.cluster.Member;
import akka.event.Logging;
import akka.event.LoggingAdapter;

public class ClusterListener extends AbstractActor {

    ////////////////////////
    // Actor Construction //
    ////////////////////////

    public static final String DEFAULT_NAME = "clusterListener";

    public static Props props(ActorRef multiplier) {
        return Props.create(ClusterListener.class, () -> new ClusterListener(multiplier));
    }

    public ClusterListener(ActorRef multiplier) {
        this.localMultiplier = multiplier;
    }

    /////////////////
    // Actor State //
    /////////////////

    private final LoggingAdapter log = Logging.getLogger(this.context().system(), this);
    private final Cluster cluster = Cluster.get(this.context().system());
    private final ActorRef localMultiplier;

    /////////////////////
    // Actor Lifecycle //
    /////////////////////

    @Override
    public void preStart() {
        this.cluster.subscribe(this.self(), MemberEvent.class, UnreachableMember.class);
    }

    @Override
    public void postStop() {
        this.cluster.unsubscribe(this.self());
    }

    ////////////////////
    // Actor Behavior //
    ////////////////////

    @Override
    public Receive createReceive() {
        return receiveBuilder().match(CurrentClusterState.class, state -> {
            this.log.info("Current members: {}", state.members());
        }).match(MemberUp.class, mUp -> {
            this.log.info("Member is Up: {}", mUp.member());
            Member member = mUp.member();
            this.log.info("trying to send message to " + member.address() + "/user/" + Multiplier.DEFAULT_NAME);
            ActorSelection remoteMultiplier = this.getContext().actorSelection(member.address() + "/user/" + Multiplier.DEFAULT_NAME);
            this.log.info("it's now "+ remoteMultiplier);
            localMultiplier.tell(new Multiplier.StartExperimentMessage(remoteMultiplier), ActorRef.noSender());
        }).match(UnreachableMember.class, mUnreachable -> {
            this.log.info("Member detected as unreachable: {}", mUnreachable.member());
        }).match(MemberRemoved.class, mRemoved -> {
            this.log.info("Member is Removed: {}", mRemoved.member());
        }).match(MemberEvent.class, message -> {
            // ignore
        }).build();
    }
}
