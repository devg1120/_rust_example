package de.anonymous.powerpingpong;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.beust.jcommander.ParameterException;
import com.beust.jcommander.Parameters;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class PowerPingPongApp {
    public static final String ACTOR_SYSTEM_NAME = "power-ping-pong";

    public static void main(String[] args) {

        MainCommand mainCommand = new MainCommand();
        SubCommand subCommand = new SubCommand();
        JCommander jCommander = JCommander.newBuilder()
                .addCommand(PowerPingPongMain.MAIN_ROLE, mainCommand)
                .addCommand(PowerPingPongSub.SUB_ROLE, subCommand)
                .build();

        try {
            jCommander.parse(args);

            if (jCommander.getParsedCommand() == null) {
                throw new ParameterException("No command given.");
            }

            switch (jCommander.getParsedCommand()) {
                case PowerPingPongMain.MAIN_ROLE:
                    PowerPingPongMain.start(ACTOR_SYSTEM_NAME, mainCommand.host, mainCommand.port, mainCommand.steps);
                    break;
                case PowerPingPongSub.SUB_ROLE:
                    PowerPingPongSub.start(ACTOR_SYSTEM_NAME, subCommand.host, subCommand.port, subCommand.mainhost, subCommand.mainport, subCommand.steps);
                    break;
                default:
                    throw new AssertionError();
            }

        } catch (ParameterException e) {
            System.out.printf("Could not parse args: %s\n", e.getMessage());
            if (jCommander.getParsedCommand() == null) {
                jCommander.usage();
            } else {
                jCommander.usage(jCommander.getParsedCommand());
            }
            System.exit(1);
        }
    }

    abstract static class CommandBase {

        public static final int DEFAULT_MAIN_PORT = 7877;
        public static final int DEFAULT_SUB_PORT = 7879;

        @Parameter(names = {"-h", "--host"}, description = "this machine's host name or IP to bind against")
        String host = this.getDefaultHost();

        String getDefaultHost() {
            try {
                return InetAddress.getLocalHost().getHostAddress();
            } catch (UnknownHostException e) {
                return "localhost";
            }
        }

        @Parameter(names = {"-p", "--port"}, description = "port to bind against", required = false)
        int port = this.getDefaultPort();

        abstract int getDefaultPort();
    }

    @Parameters(commandDescription = "start a main actor system")
    static class MainCommand extends CommandBase {

        @Override
        int getDefaultPort() {
            return DEFAULT_MAIN_PORT;
        }

        @Parameter(names = {"-s", "--steps"}, description = "max steps", required = true)
        int steps;
    }

    @Parameters(commandDescription = "start a sub actor system")
    static class SubCommand extends CommandBase {

        @Override
        int getDefaultPort() {
            return DEFAULT_SUB_PORT;
        }

        @Parameter(names = {"-s", "--steps"}, description = "max steps", required = true)
        int steps;

        @Parameter(names = {"-mp", "--mainport"}, description = "port of the main", required = false)
        int mainport = DEFAULT_MAIN_PORT;

        @Parameter(names = {"-mh", "--mainhost"}, description = "host name or IP of the main", required = true)
        String mainhost;
    }

}
