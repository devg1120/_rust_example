package de.anonymous.powerpingpong.actors;

import akka.actor.*;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Multiplier extends AbstractLoggingActor {
    public static final String DEFAULT_NAME = "multiplier";

    private final int steps;

    public Multiplier(int steps) {
        this.steps = steps;
    }

    public static Props props(int steps) {
        return Props.create(Multiplier.class, () -> new Multiplier(steps));
    }

    ////////////////////
    // Actor Messages //
    ////////////////////

    @Data @AllArgsConstructor @NoArgsConstructor
    public static class PingPongMessage implements Serializable {
        private static final long serialVersionUID = 4545299661052078209L;

        private long sendTime;
        private byte[] content;
        private int step;
    }

    @Data @AllArgsConstructor
    public static class StartExperimentMessage implements Serializable {
        private static final long serialVersionUID = 9045299661052746359L;

        private ActorSelection powerPingPongOpponent;
    }

    private byte[] randomBytes(int length) {
        byte[] b = new byte[length];
        new Random().nextBytes(b);
        return b;
    }

    ////////////////////
    // Actor Behavior //
    ////////////////////

    @Override
    public void preStart() { this.log().info("Starting Multiplier Actor"); }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(PingPongMessage.class, this::handle)
                .match(StartExperimentMessage.class, this::handle)
                .build();
    }

    private void handle(StartExperimentMessage message) throws InterruptedException {
        TimeUnit.SECONDS.sleep(1);
        byte[] powerContent = this.randomBytes(4);
        PingPongMessage serve = new PingPongMessage(System.currentTimeMillis(), powerContent, 0);
        message.getPowerPingPongOpponent().tell(serve, this.self());
    }

    private void handle(PingPongMessage message) {
        long duration = System.currentTimeMillis() - message.getSendTime();
        int step = message.getStep();
        int nextStep = step + 1;

        this.log().info("Step {}: {}", step, duration);
        ActorRef sender = getSender();

        if (nextStep >= this.steps) {
            this.log().info("Done");
            return;
        }

        byte[] powerContent = this.randomBytes(message.getContent().length * 2);

        PingPongMessage answer = new PingPongMessage(System.currentTimeMillis(), powerContent, step + 1);
        sender.tell(answer, this.self());
    }

}
