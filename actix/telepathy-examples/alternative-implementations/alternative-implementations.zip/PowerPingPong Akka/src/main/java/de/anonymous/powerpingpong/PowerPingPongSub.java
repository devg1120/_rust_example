package de.anonymous.powerpingpong;

import akka.actor.ActorSystem;
import akka.cluster.Cluster;
import com.typesafe.config.Config;
import de.anonymous.powerpingpong.actors.Multiplier;
import scala.concurrent.Await;
import scala.concurrent.duration.Duration;

import java.util.concurrent.TimeoutException;

public class PowerPingPongSub extends PowerPingPongSystem{
    public static final String SUB_ROLE = "sub";

    public static void start(String actorSystemName, String host, int port, String masterhost, int masterport, int steps) {

        final Config config = createConfiguration(actorSystemName, SUB_ROLE, host, port, masterhost, masterport);

        final ActorSystem system = createSystem(actorSystemName, config);

        Cluster.get(system).registerOnMemberUp(new Runnable() {
            @Override
            public void run() {
                system.actorOf(Multiplier.props(steps), Multiplier.DEFAULT_NAME);
            }
        });

        try {
            Await.ready(system.whenTerminated(), Duration.Inf());
        } catch (TimeoutException | InterruptedException e) {
            e.printStackTrace();
            System.exit(-1);
        }
        System.out.println("ActorSystem terminated!");
    }
}
