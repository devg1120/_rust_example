package de.anonymous.octopus.actors;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.PoisonPill;
import akka.actor.Props;
import akka.cluster.Cluster;
import akka.cluster.ClusterEvent.CurrentClusterState;
import akka.cluster.ClusterEvent.MemberUp;
import akka.cluster.Member;
import akka.cluster.MemberStatus;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import de.anonymous.octopus.OctopusMaster;
import de.anonymous.octopus.actors.Profiler.RegistrationMessage;
import de.anonymous.octopus.messages.ShutdownMessage;
import lombok.AllArgsConstructor;
import lombok.Data;

public class Worker extends AbstractActor {

	////////////////////////
	// Actor Construction //
	////////////////////////
	
	public static final String DEFAULT_NAME = "worker";
	public static final int MAX_PRIMES_PER_MESSAGE = 1000;

	public static Props props() {
		return Props.create(Worker.class);
	}

	////////////////////
	// Actor Messages //
	////////////////////
	
	@Data @AllArgsConstructor @SuppressWarnings("unused")
	public static class WorkMessage implements Serializable {
		private static final long serialVersionUID = -7643194361868862395L;
		private WorkMessage() {}
		private int id;
		private long rangeMin;
		private long rangeMax;
	}

	/////////////////
	// Actor State //
	/////////////////
	
	private final LoggingAdapter log = Logging.getLogger(this.context().system(), this);
	private final Cluster cluster = Cluster.get(this.context().system());

	/////////////////////
	// Actor Lifecycle //
	/////////////////////
	
	@Override
	public void preStart() {
		this.cluster.subscribe(this.self(), MemberUp.class);
	}

	@Override
	public void postStop() {
		this.cluster.unsubscribe(this.self());
	}

	////////////////////
	// Actor Behavior //
	////////////////////
	
	@Override
	public Receive createReceive() {
		return receiveBuilder()
				.match(CurrentClusterState.class, this::handle)
				.match(MemberUp.class, this::handle)
				.match(WorkMessage.class, this::handle)
				.match(ShutdownMessage.class, this::handle)
				.matchAny(object -> this.log.info("Received unknown message: \"{}\"", object.toString()))
				.build();
	}

	private void handle(CurrentClusterState message) {
		message.getMembers().forEach(member -> {
			if (member.status().equals(MemberStatus.up()))
				this.register(member);
		});
	}

	private void handle(MemberUp message) {
		this.register(message.member());
	}

	private void register(Member member) {
		if (member.hasRole(OctopusMaster.MASTER_ROLE))
			this.getContext()
				.actorSelection(member.address() + "/user/" + Profiler.DEFAULT_NAME)
				.tell(new RegistrationMessage(), this.self());
	}

	private void handle(WorkMessage message) {
				// Log that we started processing the current task
		this.log.info("Started discovering primes in [{},{}] ...", message.rangeMin, message.rangeMax);

		// Iterate over the range of numbers and compute the primes
		List<Long> primeBuffer = new ArrayList<>(MAX_PRIMES_PER_MESSAGE);
		for (long i = message.rangeMin; i <= message.rangeMax; i++) {
			if (isPrime(i)) {

				// Check the buffer size: We must not send too large messages, hence, also reply with intermediate results as necessary
				if (primeBuffer.size() >= MAX_PRIMES_PER_MESSAGE) {

					// Create a copy of the elements in the buffer before sending them; never send mutable objects in a message!!!
					ArrayList<Long> primeBufferCopy = new ArrayList<>(primeBuffer);

					// Send the intermediate results to the master actor
					this.getSender().tell(new Profiler.PrimesMessage(message.id, primeBufferCopy, false), this.getSelf());

					// Clear the buffer
					primeBuffer.clear();
				}

				// Add the computed prime to the buffer
				primeBuffer.add(i);
			}
		}

		// Send the primes to the master actor
		this.getSender().tell(new Profiler.PrimesMessage(message.id, primeBuffer, true), this.getSelf());
	}

	private void handle(ShutdownMessage message) {
		this.log.info("Received ShutdownMessage");
		this.getSelf().tell(PoisonPill.getInstance(), ActorRef.noSender());
		this.getContext().getSystem().terminate();
	}
	
	private boolean isPrime(long n) {
		if (n == 1)
			return false;
		
		// Check for the most basic primes
		if (n == 2 || n == 3)
			return true;

		// Check if n is an even number
		if (n % 2 == 0)
			return false;

		// Check the odds
		for (long i = 3; i * i <= n; i += 2)
			if (n % i == 0)
				return false;
		
		return true;
	}
}