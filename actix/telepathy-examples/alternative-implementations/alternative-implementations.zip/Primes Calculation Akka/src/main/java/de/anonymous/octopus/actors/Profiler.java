package de.anonymous.octopus.actors;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

import akka.actor.*;
import akka.cluster.ClusterEvent;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import de.anonymous.octopus.actors.Worker.WorkMessage;
import de.anonymous.octopus.actors.scheduling.SchedulingStrategy;
import de.anonymous.octopus.messages.ShutdownMessage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class Profiler extends AbstractActor {

	////////////////////////
	// Actor Construction //
	////////////////////////
	
	public static final String DEFAULT_NAME = "profiler";

	public Profiler(SchedulingStrategy.Factory schedulingStrategyFactory, int numMaxWorkers) {
		this.schedulingStrategy = schedulingStrategyFactory.create(this.getSelf());
		this.numMaxWorkers = numMaxWorkers;
	}

	public static Props props(SchedulingStrategy.Factory schedulingStrategyFactory, int numMaxWorkers) {
		return Props.create(Profiler.class, () -> new Profiler(schedulingStrategyFactory, numMaxWorkers));
	}

	////////////////////
	// Actor Messages //
	////////////////////
	
	@Data @AllArgsConstructor
	public static class RegistrationMessage implements Serializable {
		private static final long serialVersionUID = 4545299661052078209L;
	}

	@Data @AllArgsConstructor @SuppressWarnings("unused")
	public static class TaskMessage implements Serializable {
		private static final long serialVersionUID = -8330958742629706627L;
		private TaskMessage() {}
		private long start;
		private long end;
	}
	
	@Data @NoArgsConstructor @AllArgsConstructor @SuppressWarnings("unused")
	public static class PrimesMessage implements Serializable {
		private static final long serialVersionUID = -6823011111281387872L;
		private int requestId;
		private List<Long> primes;
		private boolean isComplete;
	}
	
	/////////////////
	// Actor State //
	/////////////////
	
	private final LoggingAdapter log = Logging.getLogger(getContext().system(), this);

	private final Set<Long> primes = new HashSet<>();
	private final Vector<TaskMessage> taskMessages = new Vector<>();
	private final SchedulingStrategy schedulingStrategy;
	private int numCurrentWorkers = 0;
	private final int numMaxWorkers;
	private int nextQueryId = 0;
	private final Vector<ActorRef> workers = new Vector<>();

	private TaskMessage task;

	////////////////////
	// Actor Behavior //
	////////////////////

	@Override
	public void preStart() {
		this.log.info("Starting Profiler Actor");
	}
	
	@Override
	public Receive createReceive() {
		return receiveBuilder()
				.match(RegistrationMessage.class, this::handle)
				.match(TaskMessage.class, this::handle)
				.match(PrimesMessage.class, this::handle)
				.matchAny(object -> this.log.info("Received unknown message: \"{}\"", object.toString()))
				.build();
	}

	private void handle(RegistrationMessage message) {
		this.context().watch(this.sender());
		
		this.schedulingStrategy.addWorker(this.sender());
		this.workers.add(this.sender());
		this.log.info("Registered {}", this.sender());

		this.numCurrentWorkers += 1;
		if (this.numCurrentWorkers >= this.numMaxWorkers) {
			this.handleTaskMessages();
		}
	}

	
	private void handle(TaskMessage message) {
		if (this.numCurrentWorkers >= this.numMaxWorkers) {
			this.handleTaskMessage(message);
		} else {
			this.taskMessages.add(message);
		}
	}

	private void handleTaskMessages() {
		for (TaskMessage message : this.taskMessages) {
			this.handleTaskMessage(message);
		}
	}

	private void handleTaskMessage(TaskMessage message) {
		// Schedule the request
		this.schedulingStrategy.schedule(this.nextQueryId, message.start, message.end);
		this.nextQueryId++;
	}
	
	private void handle(PrimesMessage message) {
		// Forward the calculated primes to the listener
		this.primes.addAll(message.primes);

		// If the worker only returned an intermediate result, no further action is required
		if (!message.isComplete)
			return;

		// Notify the scheduler that the worker has finished its task
		this.schedulingStrategy.finished(message.requestId, this.getSender());

		// Check if work is complete and stop the actor hierarchy if true
		if (this.hasFinished()) {
			this.stopSelf();
		}
	}

	private boolean hasFinished() {
		// The master has finished if (1) there will be no further requests and (2) either all requests have been processed or there are no more workers to process these requests
		return (!this.schedulingStrategy.hasTasksInProgress() || this.schedulingStrategy.countWorkers() < 1);
	}

	private void stopSelf() {
		this.log.info("Found {} primes, with {} as maximum", this.primes.size(),
				this.primes.stream()
				.max(Comparator.naturalOrder())
				.orElseGet(() -> { return 0L; }));

		for (ActorRef worker : this.workers) {
			worker.tell(new ShutdownMessage(), this.getSelf());
		}
		this.getSelf().tell(PoisonPill.getInstance(), ActorRef.noSender());
		this.getContext().getSystem().terminate();
	}
}