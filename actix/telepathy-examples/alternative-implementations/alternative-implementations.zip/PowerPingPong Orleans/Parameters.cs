using System;


namespace PowerPingPong {
    public class Parameters {
        public int steps;
        public int port;
        public string host;
        public int hostPort;
        public int id;


        public Parameters(int steps, int port, int hostPort, int id, string host) {
            this.steps = steps;
            this.port = port;
            this.hostPort = hostPort;
            this.host = host;
            this.id = id;
        }

        public static Parameters FromArgs(string[] arguments) {
            int steps = 0;
            int port = 11111;
            int hostPort = 0;
            string host = "0.0.0.0";
            int id = 0;

            foreach (string arg in arguments) {
                if (arg.StartsWith("--steps=")) {
                    steps = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--port=")) {
                    port = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--hostPort=")) {
                    hostPort = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--id=")) {
                    id = Int32.Parse(arg.Split("=")[1]);
                } else 
                if (arg.StartsWith("--host=")) {
                    host = arg.Split("=")[1];
                }
            }

            return new Parameters(steps, port, hostPort, id, host);
        }
    }
}