using System.Threading.Tasks;
using Orleans;


namespace PowerPingPong
{
    public interface IMultiplierGrain : IGrainWithIntegerKey {
        Task Init(int steps);
        Task StartExperiment(IMultiplierGrain opponent);
        Task PingPong(long sendTime, byte[] content, int step, IMultiplierGrain from);
    }
}