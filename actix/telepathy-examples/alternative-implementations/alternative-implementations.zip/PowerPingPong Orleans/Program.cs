using System;
using System.Net;
using PowerPingPong;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection; 
using Orleans.Configuration;
using Orleans;
using Orleans.Hosting;



string[] arguments = Environment.GetCommandLineArgs();
Parameters parameters = Parameters.FromArgs(arguments);

await RunMain(parameters);


async Task RunMain(Parameters parameters) {
    IPEndPoint primarySiloEndpoint;
    if (parameters.hostPort > 0) {
        primarySiloEndpoint = new IPEndPoint(IPAddress.Parse(parameters.host), parameters.hostPort);
        Console.WriteLine("Connecting to " + parameters.host);
    } else {
        primarySiloEndpoint = null;
    }

    var silo = new SiloHostBuilder().Configure<ClusterOptions>(options => {
        options.ClusterId = "power-ping-pong-cluster";
        options.ServiceId = "PowerPingPong";
    })
    .UseDevelopmentClustering(primarySiloEndpoint: primarySiloEndpoint)
    .ConfigureApplicationParts(parts => parts.AddApplicationPart(typeof(IMultiplierGrain).Assembly).WithReferences())
    .ConfigureEndpoints(siloPort: parameters.port, gatewayPort: 30000)
    .Build();

    // Start the host
    await silo.StartAsync();

    // Get the grain factory
    var grainFactory = silo.Services.GetRequiredService<IGrainFactory>();

    // Get a reference to the ProfilerGrain grain with the key 0
    if (parameters.id == 0) {
        var multiplier = grainFactory.GetGrain<IMultiplierGrain>(0);
        await multiplier.Init(parameters.steps);
    } else {
        var multiplier = grainFactory.GetGrain<IMultiplierGrain>(1);
        await multiplier.Init(parameters.steps);
        var mainMultiplier = grainFactory.GetGrain<IMultiplierGrain>(0);
        await mainMultiplier.StartExperiment(multiplier);
    }

    Console.WriteLine("Press Enter to shutdown!");
    Console.ReadLine();
    Console.WriteLine("Shutting down...");

    await silo.StopAsync();

    return;
}
