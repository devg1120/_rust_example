using System;
using System.Text;
using System.Threading.Tasks;
using Orleans;
using Orleans.Placement;


namespace PowerPingPong
{
    [PreferLocalPlacement]
    public class Multiplier: Grain, IMultiplierGrain {
        private int steps;

        private void log(string text) {
            var id = this.GetPrimaryKey().ToString();
            Console.WriteLine("Multiplier-{0}:\t{1}", id, text);
        }

        private long now() {
            TimeSpan ts = DateTime.UtcNow.Subtract(DateTime.UnixEpoch);
            long unixTimeMilliseconds = ((long)ts.TotalMilliseconds);
            return unixTimeMilliseconds;
        }

        private byte[] randomBytes(int length) {
            Random rnd = new Random();
            byte[] b = new byte[length];
            rnd.NextBytes(b);
            return b;
        }

        /////////////////////
        // Actor Behaviour //
        /////////////////////

        public Task Init(int steps) {
            this.steps = steps;
            return Task.CompletedTask;
        }
        public Task StartExperiment(IMultiplierGrain opponent) {

            byte[] content = this.randomBytes(4);

            opponent.PingPong(this.now(), content, 0, this);
            return Task.CompletedTask;
        }

        public Task PingPong(long sendTime, byte[] content, int step, IMultiplierGrain from) {
            long duration = this.now() - sendTime;
            this.log("Step " + step + ": " + duration + " | " + content.Length);
            int nextStep = step + 1;

            if (nextStep >= this.steps) {
                this.log("Done");
                return Task.CompletedTask;
            }

            byte[] doubleContent = this.randomBytes(content.Length * 2);

            from.PingPong(this.now(), doubleContent, nextStep, this);

            return Task.CompletedTask;
        }
    }
}